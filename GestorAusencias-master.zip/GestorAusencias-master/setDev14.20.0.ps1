nvm install 14.20.0; 
nvm use 14.20.0;
npm install gulp-cli yo @microsoft/generator-sharepoint --global